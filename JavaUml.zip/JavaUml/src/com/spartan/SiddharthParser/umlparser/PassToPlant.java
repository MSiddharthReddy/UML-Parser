package com.spartan.SiddharthParser.umlparser;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Collection;
import net.sourceforge.plantuml.SourceStringReader;
/**
 * Created by Siddharth
 * Last Modified March 25th
 */


//Pass all the generated strings to PlantUML
public class PassToPlant {


    public static void plantUmlGenerator(String outputName, Collection < String > strComponent, Collection < String > strRelation) throws Exception { //, Collection < String > strExtends, Collection < String > strImplements, Collection < String > strUses
        OutputStream png = new FileOutputStream(outputName);
        StringBuilder plantUmlInput = new StringBuilder();
        plantUmlInput.append("@startuml\n")
                .append("skinparam stereotypeIBackgroundColor White\n")
                .append("skinparam classBackgroundColor #A9DCDF\n")
                .append("skinparam classAttributeIconSize 0\n")
                .append("skinparam BackgroundColor White\n")
                .append("skinparam classArrowColor Black\n")
                .append("skinparam classFontColor Black\n");



        for (String item: strComponent) {
            plantUmlInput.append(item);

        }

        for (String item: strRelation) {
            plantUmlInput.append(item);

        }

        plantUmlInput.append("legend center\n")
                     .append("M.Siddharth Reddy\n 010808564\n")
                     .append("endlegend\n")
                     .append("@enduml\n");

        System.out.print(plantUmlInput.toString());

        SourceStringReader reader = new SourceStringReader(plantUmlInput.toString());

        reader.generateImage(png);

    }

}