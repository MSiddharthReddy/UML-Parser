package com.spartan.SiddharthParser.umlparser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

/**
 * Created by Siddharth
 * Last Modified March 28th
 */

public class RelationsStr implements GenStr {


    private ArrayList relationsList;
    private StringBuilder assocStr;
    private List<HashMap<String,Object>> associationMap;
    private StringBuilder extendsStrBuild = new StringBuilder();
    private List<HashMap<String,String>> extendsMapThings;
    private  StringBuilder interfaceStrBuild;
    private List<HashMap<String,String>> implementsMapList;
    private StringBuilder usesStrBuild;
    private Set< HashMap < String, String >> usesMapList;


    public RelationsStr(List<HashMap<String,Object>> associationMapList,
                        List<HashMap<String,String>> extendItemMap,
                        List<HashMap<String,String>> implementInterfaceItemMapList,
                        Set < HashMap < String, String >> usesInterfaceMapList) {

        assocStr = new StringBuilder();
        this.associationMap = associationMapList;
        relationsList = new ArrayList();
        this.extendsMapThings = extendItemMap;
        interfaceStrBuild = new StringBuilder();
        this.implementsMapList = implementInterfaceItemMapList;
        usesStrBuild = new StringBuilder();
        this.usesMapList = usesInterfaceMapList;

    }
    //Generate of PlantUML String for Association (1--*) and append to relationsList

    public void gen() {

        while(!associationMap.isEmpty()){
            String first = (String) associationMap.get(0).get("Start");
            String last = (String) associationMap.get(0).get("End");

            int i = 0;
            for(; i< associationMap.size(); i++) {
                if(associationMap.get(i).get("Start").equals(last) && associationMap.get(i).get("End").equals(first)) {
                    break;
                }
            }
            if(i< associationMap.size()) {
                if((boolean) associationMap.get(0).get("isMultiple") && (boolean) associationMap.get(i).get("isMultiple")) {
                    assocStr.append(first)
                            .append(" \"*\"")
                            .append("--")
                            .append("\"*\" ")
                            .append(last)
                            .append("\n");

                }
                else if((boolean) associationMap.get(0).get("isMultiple")) {
                    assocStr.append(first)
                            .append(" \"1\"")
                            .append("--")
                            .append("\"*\" ")
                            .append(last)
                            .append("\n");

                }
                else if((boolean) associationMap.get(i).get("isMultiple")) {
                    assocStr.append(first)
                            .append(" \"*\"")
                            .append("--")
                            .append("\"1\" ")
                            .append(last)
                            .append("\n");
                }
                else {
                    assocStr.append(first)
                            .append(" \"1\"")
                            .append("--")
                            .append("\"1\" ")
                            .append(last)
                            .append("\n");

                }
                associationMap.remove(i);
                associationMap.remove(0);
            }
            else {
                if((boolean) associationMap.get(0).get("isMultiple")) {
                    if(((String) associationMap.get(0).get("End")).toUpperCase().equals(((String) associationMap.get(0).get("Attr")).toUpperCase())){
                        assocStr.append(first)
                                .append("--")
                                .append("\"*\" ")
                                .append(last)
                                .append("\n");

                    }
                    else {
                        assocStr.append(first)
                                .append("--")
                                .append("\"*\" ")
                                .append(last)
                                .append("\n");
                    }

                }
                else {
                    assocStr.append(first)
                            .append("--")
                            .append("\"1\" ")
                            .append(last)
                            .append("\n");
                }
                associationMap.remove(0);
            }


        }
        relationsList.add(assocStr.toString());

        //Generate of PlantUML String for Inheritance and append to relationsList
        for(HashMap<String,String> extendItem : extendsMapThings){
            extendsStrBuild.append(extendItem.get("Parent"));
            extendsStrBuild.append("<|--");
            extendsStrBuild.append(extendItem.get("Child"));
            extendsStrBuild.append("\n");
        }
        relationsList.add(extendsStrBuild.toString());

        //Generate of PlantUML String for Implements and append to relationsList
        for(HashMap<String,String> implementInterfaceItem : implementsMapList) {

            interfaceStrBuild.append(implementInterfaceItem.get("Interface"));
            interfaceStrBuild.append("<|.. ");
            interfaceStrBuild.append(implementInterfaceItem.get("ImClass"));
            interfaceStrBuild.append("\n");
        }
        relationsList.add(interfaceStrBuild.toString());

        //Generate of PlantUML String for Dependancy and append to relationsList
        for (HashMap < String, String > useInterfaceItem: usesMapList) {

            usesStrBuild.append(useInterfaceItem.get("UseName"));
            usesStrBuild.append("..>");
            usesStrBuild.append(useInterfaceItem.get("InterfaceName"));
            usesStrBuild.append(": uses\n");

        }
        relationsList.add(usesStrBuild.toString());

    }

    public List<String> getStringList() {
         return relationsList;
    }

}




