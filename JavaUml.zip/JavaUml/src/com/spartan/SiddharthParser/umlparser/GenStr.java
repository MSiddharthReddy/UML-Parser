package com.spartan.SiddharthParser.umlparser;

import java.util.List;

/**
 * Created by Siddharth
 * Last Modified Feb 22nd
 */

public interface GenStr {

    public abstract void gen();

    public abstract List < String > getStringList();

}