package com.spartan.SiddharthParser.umlparser;

import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import java.util.*;

/**
 * Created by Siddharth
 * Last Modified March 21st
 */

public class GetComponents {


    public static List < String > classNames;
    public static List < String > interfaceNames;
    static String className;

    static List < HashMap < String, String >> extendsList;
    static List < HashMap < String, String >> implementsList;
    static List < HashMap < String, Object >> associationList;
    static Set < HashMap < String, String >> usesList;


    static boolean isInterface;
    static boolean isAbstract = false;
    static int classModifiers;

    static List < ClassOrInterfaceType > classExtends;
    static List < ClassOrInterfaceType > classImplements;

    static List < String > classAttr;
    static List < Integer > classAttrMod;
    static List < String > classAttrType;

    static List < String > methodNames;
    static ArrayList < Boolean > isGetter;
    static ArrayList < Boolean > isSetter;
    static ArrayList < String > setGetterSetterNames;
    static ArrayList < String > setGetterSetterAttr;

    static List < Integer > methodModifiers;
    static List < String > methodTypes;
    static List < List < Parameter >> methodParameters;

    static List < String > cnstrrNames;
    static List < Integer > cnstrModifiers;
    static List < List < Parameter >> cnstrParameters;

    static ArrayList < String > innerAttributeTypes;




    public GetComponents() {
        classNames = new ArrayList < > ();
        interfaceNames = new ArrayList < > ();

        associationList = new ArrayList < > ();
        extendsList = new ArrayList < > ();
        usesList = new LinkedHashSet<>();
        implementsList = new ArrayList < > ();

        classExtends = new ArrayList < > ();
        classImplements = new ArrayList < > ();

        classAttr = new ArrayList < > ();
        classAttrMod = new ArrayList < > ();
        classAttrType = new ArrayList < > ();

        methodNames = new ArrayList < > ();

        isGetter = new ArrayList < > ();
        isSetter = new ArrayList < > ();
        setGetterSetterNames = new ArrayList < > ();
        setGetterSetterAttr = new ArrayList < > ();

        methodModifiers = new ArrayList < > ();
        methodTypes = new ArrayList < > ();
        methodParameters = new ArrayList < > ();

        cnstrrNames = new ArrayList < > ();
        cnstrModifiers = new ArrayList < > ();
        cnstrParameters = new ArrayList < > ();
        innerAttributeTypes = new ArrayList < > ();



    }


    //Checking ComponentStr and UMLStrImplements using VoidVisitorAdapter
    public static class ClassAnalyse extends VoidVisitorAdapter {

        @Override
        public void visit(ClassOrInterfaceDeclaration n, Object arg) {

            className = n.getName();
            isInterface = n.isInterface();
            classExtends = n.getExtends();
            classImplements = n.getImplements();
            classModifiers = n.getModifiers();
            if (ModifierSet.isAbstract(classModifiers)) {
                isAbstract = true;
            }

        }
        public void check(){
            if (isInterface)
                interfaceNames.add(className);
            else
                classNames.add(className);

            //generating map for Parent class and sub class
            if (classExtends != null) {
                for (ClassOrInterfaceType item: classExtends) {
                    HashMap < String, String > extendItem = new HashMap < > ();
                    extendItem.put("Parent", item.getName());
                    extendItem.put("Child", className);
                    GetComponents.extendsList.add(extendItem);

                }
            }
            //generating map for interface nd its implemented class
            if (classImplements != null) {
                for (ClassOrInterfaceType item: classImplements) {
                    HashMap < String, String > implementItem = new HashMap < > ();
                    implementItem.put("Interface", item.getName());
                    implementItem.put("ImClass", className);
                    implementsList.add(implementItem);
                }
            }
        }

    }

    //Checking for Variables

    public static class AttrAnalyse extends VoidVisitorAdapter {

        @Override
        public void visit(FieldDeclaration n, Object arg) {

            classAttrType.add(n.getType().toString());
            String varName = n.getVariables().get(0).toString();
            if (varName.contains("=")) {
                varName = varName.substring(0, varName.indexOf("="));
            }
            classAttr.add(varName);
            classAttrMod.add(n.getModifiers());
        }
    }

    //Checking methods
    public static class MthdAnalyse extends VoidVisitorAdapter {

        @Override
        public void visit(MethodDeclaration n, Object arg) {
            methodModifiers.add(n.getModifiers());
            methodNames.add(n.getName());
            methodTypes.add(n.getType().toString());
            methodParameters.add(n.getParameters());



            //Checking if the method is Setter
            if (n.getName().toUpperCase().contains("SET")) {

                for (String nameItem: classAttr) {
                    if (n.getName().toUpperCase().equals(("set" + nameItem).toUpperCase())) {
                        setGetterSetterNames.add(n.getName());
                        setGetterSetterAttr.add(nameItem);
                        isGetter.add(false);
                        isSetter.add(true);
                    }
                }

            }
            //Checking if the method is Getter
            else if (n.getName().toUpperCase().contains("GET")) {

                for (String nameItem: classAttr) {
                    if (n.getName().toUpperCase().equals(("get" + nameItem).toUpperCase())) {
                        setGetterSetterNames.add(n.getName());
                        setGetterSetterAttr.add(nameItem);
                        isGetter.add(true);
                        isSetter.add(false);
                    }
                }
            }



        }

    }


    //Check for constructor
    public static class CnstrAnalyse extends VoidVisitorAdapter {

        @Override
        public void visit(ConstructorDeclaration n, Object arg) {
            cnstrModifiers.add(n.getModifiers());
            cnstrrNames.add(n.getName());
            cnstrParameters.add(n.getParameters());


        }
    }

    //Check for inner attributes in methods
    public static class VarAnalyse extends VoidVisitorAdapter {
        @Override
        public void visit(VariableDeclarationExpr n, Object arg) {
            innerAttributeTypes.add(n.getType().toString());
        }
    }

    public static void reset() {

        methodNames.clear();
        methodModifiers.clear();
        methodTypes.clear();
        methodParameters.clear();
        setGetterSetterNames.clear();
        setGetterSetterAttr.clear();
        isGetter.clear();
        isSetter.clear();
        classAttr.clear();
        classAttrMod.clear();
        classAttrType.clear();
        cnstrrNames.clear();
        cnstrModifiers.clear();
        cnstrParameters.clear();
        innerAttributeTypes.clear();

    }


    public static boolean fldGetSet(String fieldName) {
        boolean hasSet = false;
        boolean hasGet = false;
        for (int i = 0; i < setGetterSetterAttr.size(); i++) {

            if (setGetterSetterAttr.get(i).equals(fieldName)) {
                if (isSetter.get(i)) hasSet = true;
                if (isGetter.get(i)) hasGet = true;
            }
        }
        if (hasSet && hasGet)
            return true;

        return false;
    }

    public static boolean chckGetSet(String methodName) {

        for (String methodItem: setGetterSetterNames) {
            if (methodItem.equals(methodName)) {
                int index = setGetterSetterNames.indexOf(methodItem);
                if (isSetter.get(index) || isGetter.get(index))
                    return true;
            }
        }

        return false;
    }



}