package com.spartan.SiddharthParser.umlparser;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseException;
import com.github.javaparser.ast.CompilationUnit;
import java.io.*;


/**
 * Created by Siddharth
 * Last Modified March 28th
 */

public class Main {

    private static GetComponents getComponents = new GetComponents();
    private static ComponentStr componentStr = new ComponentStr();

    public static void main(String[] args) throws IOException, ParseException {


        String directory, outName;
        //get input via arguments
        directory = args[0];
        outName = args[1];

        //Seperating interfaces and classes. .java files are gathered through getfiles() function.
        for (File file : getFiles(directory)) {

            CompilationUnit unit = JavaParser.parse(file);
            new GetComponents.ClassAnalyse().visit(unit, null);
            new GetComponents.ClassAnalyse().check();
        }


        for (File file : getFiles(directory)) {

            CompilationUnit unit = JavaParser.parse(file);
            new GetComponents.ClassAnalyse().visit(unit, null);
            new GetComponents.VarAnalyse().visit(unit, null);
            new GetComponents.AttrAnalyse().visit(unit, null);
            new GetComponents.MthdAnalyse().visit(unit, null);
            new GetComponents.CnstrAnalyse().visit(unit, null);


            //Generate a Component string for Plant consisting of associations, extends, implements and uses
            componentStr.gen();
            GetComponents.reset();
        }

        //Generate a Relations string for Plant consisting of associations, extends, implements and uses
        RelationsStr assocStrGenerator = new RelationsStr(GetComponents.associationList,GetComponents.extendsList,GetComponents.implementsList,GetComponents.usesList);
        assocStrGenerator.gen();


        //Pass both the strings generated to plantUMl via PassToPlant
        try {

            PassToPlant.plantUmlGenerator(outName, componentStr.getStringList(), assocStrGenerator.getStringList());

        } catch (Exception e) {

            e.printStackTrace();
        }


    }


    //function to return .java files from the given directory
    public static File[] getFiles(String dirName) {
        File dir = new File(dirName);

        return dir.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String filename) {
                return filename.endsWith(".java");
            }
        });
    }

}




