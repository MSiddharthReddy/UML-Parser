package com.spartan.SiddharthParser.umlparser;

import com.github.javaparser.ast.body.ModifierSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.github.javaparser.ast.body.Parameter;

/**
 * Created by Siddharth
 * Last Modified March 22nd
 */

//GenStr of String for componentStr
public class ComponentStr implements GenStr {

    private StringBuilder componentStr;
    private ArrayList < String > componentList;


    public ComponentStr() {
        componentStr = new StringBuilder();
        componentList = new ArrayList < > ();

    }

    @Override
    public void gen() {


        if (GetComponents.isInterface) {
            componentStr.append("interface ")
                    .append(GetComponents.className)
                    .append(" {\n");


        } else {
            if (ModifierSet.isAbstract(GetComponents.classModifiers)) {
                componentStr.append("abstract class ")
                        .append(GetComponents.className)
                        .append(" {\n");


            } else {

                componentStr.append("class ")
                        .append(GetComponents.className)
                        .append(" {\n");


            }
        }

        // Generating field string
        for (String field: GetComponents.classAttr) {

            int a = GetComponents.classAttr.indexOf(field);

            // Check if the attribute leads to associations
            String chckAssociation = "";
            if (GetComponents.classAttrType.get( a ).indexOf('[') >= 0) {
                chckAssociation += GetComponents.classAttrType.get( a ).substring(0, GetComponents.classAttrType.get( a ).indexOf('['));
            } else if (GetComponents.classAttrType.get( a ).contains("Collection") ||
                       GetComponents.classAttrType.get( a ).contains("Map") ||
                       GetComponents.classAttrType.get( a ).contains("List") ||
                       GetComponents.classAttrType.get( a ).contains("Set")) {
                chckAssociation += GetComponents.classAttrType.get( a ).substring(GetComponents.classAttrType.get( a ).indexOf('<') + 1, GetComponents.classAttrType.get( a ).indexOf('>'));
            }

            if (GetComponents.classNames.indexOf(GetComponents.classAttrType.get( a )) >= 0 ||
                    GetComponents.classNames.indexOf(chckAssociation) >= 0 ||
                    GetComponents.interfaceNames.indexOf(GetComponents.classAttrType.get( a )) >= 0 ||
                    GetComponents.interfaceNames.indexOf(chckAssociation) >= 0) {

                HashMap < String, Object > associationMap = new HashMap < > ();
                associationMap.put("Start", GetComponents.className);


                if (chckAssociation != "") {

                    associationMap.put("End", chckAssociation);
                } else {

                    associationMap.put("End", GetComponents.classAttrType.get( a ));
                }
                associationMap.put("Attr", field);


                if (chckAssociation != "") {
                    associationMap.put("isMultiple", true);

                } else {
                    associationMap.put("isMultiple", false);

                }
                System.out.println(associationMap.toString());
                GetComponents.associationList.add(associationMap);


            } else { //or add it to attr list

                StringBuilder attrStrBuildr = new StringBuilder();

                if (GetComponents.classAttrType.get( a ).indexOf('[') >= 0) {

                    attrStrBuildr.append(GetComponents.classAttrType.get( a ).substring(0, GetComponents.classAttrType.get( a ).indexOf('[')))
                            .append("(*)");


                } else if (GetComponents.classAttrType.get( a ).contains("Collection") ||
                           GetComponents.classAttrType.get( a ).contains("Map") ||
                           GetComponents.classAttrType.get( a ).contains("List") ||
                           GetComponents.classAttrType.get( a ).contains("Set")) {

                    attrStrBuildr.append(GetComponents.classAttrType.get( a ).substring(GetComponents.classAttrType.get( a ).indexOf('<') + 1, GetComponents.classAttrType.get( a ).indexOf('>')))
                            .append("(*)");

                } else {

                    attrStrBuildr.append(GetComponents.classAttrType.get( a ));

                }

                if (ModifierSet.isPublic(GetComponents.classAttrMod.get( a ))) {

                    componentStr.append("+")
                            .append(field)
                            .append(":")
                            .append(attrStrBuildr.toString())
                            .append("\n");


                } else if (GetComponents.fldGetSet(field)) {
                    componentStr.append("+")
                            .append(field)
                            .append(":")
                            .append(attrStrBuildr.toString())
                            .append("\n");


                } else if (ModifierSet.isPrivate(GetComponents.classAttrMod.get( a ))) {
                    componentStr.append("-")
                            .append(field)
                            .append(":")
                            .append(attrStrBuildr.toString())
                            .append("\n");



                }
            }

        }
        componentStr.append("__\n");

        //Generating String for Constructors
        for (String methodName: GetComponents.cnstrrNames) {
            int index = GetComponents.cnstrrNames.indexOf(methodName);
            if (ModifierSet.isPublic(GetComponents.cnstrModifiers.get(index))) {

                StringBuilder paramStringBuilder = new StringBuilder();

                for (Parameter parameterSingle: GetComponents.cnstrParameters.get(index)) {
                    String[] parts = parameterSingle.toString().split(" ");
                    paramStringBuilder.append(parts[1])
                            .append(":")
                            .append(parameterSingle.getType());


                    if (GetComponents.cnstrParameters.get(index).indexOf(parameterSingle) + 1 != GetComponents.cnstrParameters.get(index).size())
                        paramStringBuilder.append(",");
                }
                componentStr.append("+")
                        .append(methodName)
                        .append("(")
                        .append(paramStringBuilder.toString())
                        .append(")")
                        .append("\n");


            }

            //checking for dependency
            for (Parameter parameterSingle: GetComponents.cnstrParameters.get(index)) {
                String chckDependency = "";
                String paramtertype = parameterSingle.getType().toString();

                if (paramtertype.indexOf('[') >= 0) {
                    chckDependency += paramtertype.substring(0, paramtertype.indexOf('['));
                } else if (paramtertype.contains("Collection") ||
                           paramtertype.contains("List") ||
                           paramtertype.contains("Map") ||
                           paramtertype.contains("Set")) {
                    chckDependency += paramtertype.substring(paramtertype.indexOf('<') + 1, paramtertype.indexOf('>'));
                } else
                    chckDependency += paramtertype;


                for (String interfaceName: GetComponents.interfaceNames) {

                    if (interfaceName.equals(chckDependency)) {
                        HashMap < String, String > usesInterfaceItem = new HashMap < > ();
                        usesInterfaceItem.put("InterfaceName", interfaceName);
                        usesInterfaceItem.put("UseName", GetComponents.className);


                        if (GetComponents.classNames.contains(GetComponents.className))
                            GetComponents.usesList.add(usesInterfaceItem);
                    }
                }
            }
        }
        //Generating Strings for Methods
        for (String methodNames: GetComponents.methodNames) {
            int index = GetComponents.methodNames.indexOf(methodNames);
            if ((ModifierSet.isPublic(GetComponents.methodModifiers.get(index)) ||
                    GetComponents.interfaceNames.contains(GetComponents.className)) &&
                    !GetComponents.chckGetSet(methodNames)) {
                String parameterStr = "";
                //Checking the parameters
                for (Parameter param: GetComponents.methodParameters.get(index)) {
                    String[] parts = param.toString().split(" ");
                    parameterStr += parts[1] + ":" + param.getType();
                    if (GetComponents.methodParameters.get(index).indexOf(param) + 1 != GetComponents.methodParameters.get(index).size())
                        parameterStr += ",";
                }
                componentStr.append("+")
                        .append(methodNames)
                        .append("(")
                        .append(parameterStr)
                        .append("):")
                        .append(GetComponents.methodTypes.get(index))
                        .append("\n");

            }


            //checking for dependency
            for (Parameter parameterSingle: GetComponents.methodParameters.get(index)) {
                String chckDependency = "";
                String paratype = parameterSingle.getType().toString();

                if (paratype.indexOf('[') >= 0) {
                    chckDependency += paratype.substring(0, paratype.indexOf('['));
                } else if (paratype.contains("Collection") ||
                           paratype.contains("List") ||
                           paratype.contains("Map") ||
                           paratype.contains("Set")) {
                    chckDependency += paratype.substring(paratype.indexOf('<') + 1, paratype.indexOf('>'));
                } else
                    chckDependency += paratype;


                for (String interfaceName: GetComponents.interfaceNames) {
                    if (interfaceName.equals(chckDependency)) {

                        HashMap < String, String > usesInterfaceItem = new HashMap < > ();
                        usesInterfaceItem.put("InterfaceName", interfaceName);
                        usesInterfaceItem.put("UseName", GetComponents.className);

                        if (GetComponents.classNames.contains(GetComponents.className))
                            GetComponents.usesList.add(usesInterfaceItem);
                    }
                }
            }


            //checking for dependency
            String chckDependency = "";
            String returntype = GetComponents.methodTypes.get(index);
            if (returntype.indexOf('[') >= 0) {
                chckDependency += returntype.substring(0, returntype.indexOf('['));
            } else if (returntype.contains("Collection") ||
                    returntype.contains("List") ||
                    returntype.contains("Map") ||
                    returntype.contains("Set")) {
                chckDependency += returntype.substring(returntype.indexOf('<') + 1, returntype.indexOf('>'));
            } else
                chckDependency += returntype;

            for (String interfaceName: GetComponents.interfaceNames) {
                if (interfaceName.equals(chckDependency)) {

                    HashMap < String, String > usesInterfaceItem = new HashMap < > ();
                    usesInterfaceItem.put("InterfaceName", interfaceName);
                    usesInterfaceItem.put("UseName", GetComponents.className);


                    if (GetComponents.classNames.contains(GetComponents.className))
                        GetComponents.usesList.add(usesInterfaceItem);
                }
            }

        }

        componentStr.append("}\n");

        //Checking for UMLStrImplements inside the methods
        for (String innervarType: GetComponents.innerAttributeTypes) {
            for (String interfaceName: GetComponents.interfaceNames) {
                if (interfaceName.equals(innervarType)) {
                    HashMap < String, String > uses = new HashMap < > ();
                    uses.put("InterfaceName", interfaceName);
                    uses.put("UseName", GetComponents.className);


                    if (GetComponents.classNames.contains(GetComponents.className))
                        GetComponents.usesList.add(uses);

                }
            }
        }

    }


    @Override
    public List < String > getStringList() {
        componentList.add(componentStr.toString());
        return componentList;
    }


}